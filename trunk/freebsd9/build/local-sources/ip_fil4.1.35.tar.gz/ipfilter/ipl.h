/*
 * Copyright (C) 1993-2001, 2003 by Darren Reed.
 *
 * See the IPFILTER.LICENCE file for details on licencing.
 *
 * @(#)ipl.h	1.21 6/5/96
 * $Id$
 */

#ifndef	__IPL_H__
#define	__IPL_H__

#define	IPL_VERSION	"IP Filter: v4.1.34"

#define	IPFILTER_VERSION	4013400

#endif
